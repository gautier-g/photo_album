package album.vues;

public interface Observateur {
    public void reagir();
}
